import React from 'react'
import './style/Mid1.css';


export default function Mid1() {
  return (
    <div className='filter'>
        <h1>Best Sellers</h1>
        <p>Price Range</p>
        <button>Filter</button>
        <button>Show All</button>
        <ol>Filter
            
                <li>All</li>
                <li>Awesome</li>
                <li>Wonderful</li>
                <li>Creative</li>
                <li>Animative</li>
                <li>Responsive</li>
            
        </ol>
    </div>
  )
}


