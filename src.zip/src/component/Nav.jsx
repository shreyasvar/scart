import React from 'react'
import './style/Nav.css';

export default function Nav() {
    return (
        <>
        <div className='nav'>
            <div className='storepic'>
                <img src="images/logo2.png" alt="" />
                <h1>StoreM1</h1>
                <div className='headss'>
                    <div><a href='#'>Blocks</a></div>
                    <div><a href='#'>Pages</a></div>
                    <div><a href='#'>About</a></div>
                    <div><a href='#'>Contact</a></div>
                    <div><a href='#'>BUY NOW</a></div>
                </div>
            </div>
        </div>
        <div className='mid'>
            <img src="images/BG.jpg" alt="" />
        </div>
        <div className='shop'>Shop For You</div>
        </>
    )
}
